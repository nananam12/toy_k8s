//go:build !linux
// +build !linux

// Copyright Istio Authors
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package nodeagent

import (
	"context"
	"net/netip"

	"istio.io/istio/pkg/kube"
	corev1 "k8s.io/api/core/v1"
)

type meshDataplane struct{}

func initMeshDataplane(client kube.Client, args AmbientArgs) (*meshDataplane, error) {
	return nil, errNotImplemented
}

func (*meshDataplane) ConstructInitialSnapshot(existingAmbientPods []*corev1.Pod) error {
	return errNotImplemented
}

func (*meshDataplane) Start(ctx context.Context) {
	// not supported
	return
}

func (*meshDataplane) AddPodToMesh(ctx context.Context, pod *corev1.Pod, podIPs []netip.Addr, netNs string) error {
	return errNotImplemented
}

func (*meshDataplane) RemovePodFromMesh(ctx context.Context, pod *corev1.Pod, isDelete bool) error {
	return errNotImplemented
}

func (*meshDataplane) Stop(skipCleanup bool) {
	// not supported
	return
}
